package com.arushield.timerguru

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.load(applicationContext)
        Engines.init(applicationContext)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(primary = Amber, background = BgC, surface = Surf)
            ) {
                App()
            }
        }
    }
}
