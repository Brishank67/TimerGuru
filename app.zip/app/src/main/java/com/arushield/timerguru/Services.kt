package com.arushield.timerguru

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Calendar

object Notifier {
    const val CH_TIMER = "tg_timer"
    const val CH_ALERT = "tg_alert"
    const val CH_ALARM = "tg_alarm"

    fun channels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_TIMER, t("Running timers", "चल रहे टाइमर"), NotificationManager.IMPORTANCE_LOW)
        )
        val alert = NotificationChannel(CH_ALERT, t("Timer alerts", "टाइमर अलर्ट"), NotificationManager.IMPORTANCE_HIGH)
        alert.setSound(null, null)
        nm.createNotificationChannel(alert)
        val alarm = NotificationChannel(CH_ALARM, t("Alarms", "अलार्म"), NotificationManager.IMPORTANCE_HIGH)
        alarm.setSound(null, null)
        nm.createNotificationChannel(alarm)
    }

    fun openApp(ctx: Context): PendingIntent =
        PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)

    fun post(ctx: Context, title: String, text: String, id: Int) {
        try {
            channels(ctx)
            val n = NotificationCompat.Builder(ctx, CH_ALERT)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(title)
                .setContentText(text)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(openApp(ctx))
                .build()
            ctx.getSystemService(NotificationManager::class.java).notify(id, n)
        } catch (_: Exception) {
        }
    }
}

object TimerAlarm {
    private fun pi(ctx: Context, code: Int, label: String): PendingIntent {
        val i = Intent(ctx, TimerEndReceiver::class.java)
        i.putExtra("code", code)
        i.putExtra("label", label)
        return PendingIntent.getBroadcast(ctx, code, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    fun set(ctx: Context, code: Int, atWall: Long, label: String) {
        try {
            val am = ctx.getSystemService(AlarmManager::class.java)
            am.setAlarmClock(AlarmManager.AlarmClockInfo(atWall, Notifier.openApp(ctx)), pi(ctx, code, label))
        } catch (_: Exception) {
        }
    }

    fun cancel(ctx: Context, code: Int) {
        try {
            val am = ctx.getSystemService(AlarmManager::class.java)
            am.cancel(pi(ctx, code, ""))
        } catch (_: Exception) {
        }
    }
}

object AlarmScheduler {
    fun nextTrigger(a: AlarmItem): Long {
        val now = System.currentTimeMillis()
        for (add in 0..7) {
            val c = Calendar.getInstance()
            c.add(Calendar.DAY_OF_YEAR, add)
            c.set(Calendar.HOUR_OF_DAY, a.hour)
            c.set(Calendar.MINUTE, a.minute)
            c.set(Calendar.SECOND, 0)
            c.set(Calendar.MILLISECOND, 0)
            val dow = c.get(Calendar.DAY_OF_WEEK)
            if (c.timeInMillis > now && (a.days.isEmpty() || a.days.contains(dow))) return c.timeInMillis
        }
        return now + 86400000L
    }

    private fun pi(ctx: Context, id: Int): PendingIntent {
        val i = Intent(ctx, AlarmReceiver::class.java)
        i.putExtra("id", id)
        return PendingIntent.getBroadcast(ctx, 1000 + id, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    fun schedule(ctx: Context, a: AlarmItem) {
        try {
            if (!a.enabled) {
                cancel(ctx, a.id)
                return
            }
            val am = ctx.getSystemService(AlarmManager::class.java)
            am.setAlarmClock(AlarmManager.AlarmClockInfo(nextTrigger(a), Notifier.openApp(ctx)), pi(ctx, a.id))
        } catch (_: Exception) {
        }
    }

    fun cancel(ctx: Context, id: Int) {
        try {
            ctx.getSystemService(AlarmManager::class.java).cancel(pi(ctx, id))
        } catch (_: Exception) {
        }
    }

    fun rescheduleAll(ctx: Context) {
        Alarms.list.forEach { schedule(ctx, it) }
    }
}

class TimerService : Service() {
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var job: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    private fun build(text: String): Notification =
        NotificationCompat.Builder(this, Notifier.CH_TIMER)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("TimerGuru")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(Notifier.openApp(this))
            .build()

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Notifier.channels(this)
        startForeground(1, build(Engines.status() ?: "TimerGuru"))
        if (job == null) {
            job = scope.launch {
                val nm = getSystemService(NotificationManager::class.java)
                while (isActive) {
                    val s = Engines.status()
                    if (s == null) {
                        stopSelf()
                        break
                    }
                    nm.notify(1, build(s))
                    delay(1000)
                }
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        job?.cancel()
        super.onDestroy()
    }

    companion object {
        fun ensure(ctx: Context) {
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, TimerService::class.java))
            } catch (_: Exception) {
            }
        }
    }
}

class RingService : Service() {
    private var player: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            stopSelf()
            return START_NOT_STICKY
        }
        Prefs.load(applicationContext)
        Notifier.channels(this)
        val label = intent?.getStringExtra("label") ?: "TimerGuru"
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, RingService::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = Notifier.openApp(this)
        val n = NotificationCompat.Builder(this, Notifier.CH_ALARM)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(label)
            .setContentText(t("Alarm", "अलार्म"))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setFullScreenIntent(open, true)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(0, t("Stop", "बंद करें"), stop)
            .build()
        startForeground(2, n)
        startRinging()
        handler.postDelayed({ stopSelf() }, 120000L)
        return START_NOT_STICKY
    }

    private fun startRinging() {
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            mp.setDataSource(this, uri)
            mp.isLooping = true
            mp.prepare()
            mp.start()
            player = mp
        } catch (_: Exception) {
        }
        try {
            val v = getSystemService(Vibrator::class.java)
            v?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 600, 400), 0))
        } catch (_: Exception) {
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try {
            player?.stop()
        } catch (_: Exception) {
        }
        player?.release()
        player = null
        try {
            getSystemService(Vibrator::class.java)?.cancel()
        } catch (_: Exception) {
        }
        super.onDestroy()
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val app = ctx.applicationContext
        Alarms.load(app)
        val id = intent.getIntExtra("id", -1)
        val a = Alarms.list.firstOrNull { it.id == id } ?: return
        val i = Intent(app, RingService::class.java)
        i.putExtra("label", a.label.ifBlank { "TimerGuru" })
        ContextCompat.startForegroundService(app, i)
        if (a.days.isEmpty()) {
            Alarms.upsert(app, a.copy(enabled = false))
        } else {
            AlarmScheduler.schedule(app, a)
        }
    }
}

class TimerEndReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val app = ctx.applicationContext
        Engines.init(app)
        val code = intent.getIntExtra("code", 0)
        val label = intent.getStringExtra("label") ?: "TimerGuru"
        val e = Engines.byCode(code)
        if (e.items.isNotEmpty()) {
            Engines.tickAll()
        } else {
            Alert.fire(app)
            Notifier.post(app, label, t("Time is up", "समय पूरा हुआ"), 100 + code)
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val app = ctx.applicationContext
        Alarms.load(app)
        AlarmScheduler.rescheduleAll(app)
    }
}
