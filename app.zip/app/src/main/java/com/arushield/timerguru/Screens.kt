package com.arushield.timerguru

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

val BgC = Color(0xFF0F1420)
val Surf = Color(0xFF181F30)
val Line = Color(0xFF263049)
val Amber = Color(0xFFF5A524)
val Ink = Color(0xFFF2F4F8)
val Mute = Color(0xFF9AA4B8)

@Composable
fun Txt(
    text: String,
    size: Int = 14,
    weight: FontWeight = FontWeight.Normal,
    color: Color = Ink,
    modifier: Modifier = Modifier,
    align: TextAlign? = null
) {
    Text(text, color = color, fontSize = size.sp, fontWeight = weight, modifier = modifier, textAlign = align)
}

@Composable
fun Pill(text: String, primary: Boolean, enabled: Boolean = true, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        enabled = enabled,
        shape = RoundedCornerShape(28.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (primary) Amber else Surf,
            contentColor = if (primary) BgC else Ink,
            disabledContainerColor = Surf,
            disabledContentColor = Mute
        ),
        contentPadding = PaddingValues(horizontal = 20.dp),
        modifier = Modifier.height(56.dp)
    ) {
        Text(text, fontSize = 15.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .defaultMinSize(minHeight = 44.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(if (selected) Amber else Surf)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center
    ) {
        Txt(text, 14, FontWeight.SemiBold, if (selected) BgC else Ink)
    }
}

@Composable
fun Header(title: String, sub: String) {
    Column(Modifier.padding(start = 24.dp, end = 24.dp, top = 16.dp)) {
        Text("TIMERGURU", color = Amber, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        Txt(title, 28, FontWeight.Bold)
        Txt(sub, 14, color = Mute)
    }
}

@Composable
fun Stepper(value: Int, unit: String, min: Int, max: Int, onChange: (Int) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Chip("−", false) { if (value > min) onChange(value - 1) }
        Txt("$value $unit", 18, FontWeight.SemiBold, modifier = Modifier.widthIn(min = 90.dp), align = TextAlign.Center)
        Chip("+", false) { if (value < max) onChange(value + 1) }
    }
}

@Composable
fun Ring(progress: Float, big: String, small: String) {
    Box(Modifier.size(260.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val sw = 12.dp.toPx()
            val inset = sw / 2
            val sz = Size(size.width - sw, size.height - sw)
            drawArc(Line, 0f, 360f, false, Offset(inset, inset), sz, style = Stroke(sw))
            drawArc(
                Amber, -90f, 360f * progress.coerceIn(0f, 1f), false,
                Offset(inset, inset), sz, style = Stroke(sw, cap = StrokeCap.Round)
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Txt(big, 52, FontWeight.Bold)
            Txt(small, 13, color = Mute)
        }
    }
}

@Composable
fun tfColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = Ink,
    unfocusedTextColor = Ink,
    focusedBorderColor = Amber,
    unfocusedBorderColor = Line,
    cursorColor = Amber
)

@Composable
fun ChainList(c: ChainTimer) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Surf)
            .padding(horizontal = 16.dp, vertical = 4.dp)
    ) {
        c.items.forEachIndexed { i, item ->
            val done = c.finished || i < c.index
            val now = !c.finished && i == c.index
            Row(
                Modifier.fillMaxWidth().padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Txt(
                    (if (done) "✓  " else if (now) "●  " else "○  ") + item.name,
                    15,
                    if (now) FontWeight.Bold else FontWeight.Normal,
                    if (now) Amber else if (done) Mute else Ink
                )
                Txt(fmt(if (done) c.spent.getOrElse(i) { 0L } else item.ms), 15, color = Mute)
            }
        }
    }
}

@Composable
fun ChainRun(c: ChainTimer, modifier: Modifier, onExit: () -> Unit) {
    val view = LocalView.current
    SideEffect { view.keepScreenOn = c.running }
    val cur = c.items.getOrNull(c.index)
    Column(
        modifier.verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        if (c.finished) {
            Txt(t("Complete", "पूरा हुआ"), 28, FontWeight.Bold, Amber)
            Txt(t("Time spent", "लगा हुआ समय"), 14, color = Mute)
        } else if (cur != null) {
            Ring(c.remainingMs.toFloat() / cur.ms.toFloat(), fmt(c.remainingMs), cur.name)
            if (c.items.size > 1) {
                val totalLeft = c.remainingMs + c.items.drop(c.index + 1).sumOf { it.ms }
                Txt(t("Total left", "कुल समय शेष") + ": " + fmt(totalLeft), 14, color = Mute)
            }
        }
        if (c.items.size > 1 || c.finished) ChainList(c)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (c.finished) {
                Pill(t("Done", "ठीक है"), true) { onExit() }
            } else {
                Pill(t("Stop", "बंद करें"), false) { onExit() }
                if (c.items.size > 1) Pill(t("Skip", "छोड़ें"), false) { c.skip() }
                Pill(if (c.running) t("Pause", "रोकें") else t("Resume", "जारी रखें"), true) {
                    if (c.running) c.pause() else c.start()
                }
            }
        }
    }
}

@Composable
fun TimerScreen() {
    Column(Modifier.fillMaxSize()) {
        Header(t("Timer", "टाइमर"), t("Set a countdown for your study block", "पढ़ाई के लिए समय तय करें"))
        if (Engines.timerRun) {
            ChainRun(Engines.timer, Modifier.weight(1f)) {
                Engines.timer.reset()
                Engines.timerRun = false
            }
        } else {
            TimerSetup(Modifier.weight(1f))
        }
    }
}

@Composable
fun TimerSetup(modifier: Modifier) {
    val e = Engines
    val unit = t("min", "मिनट")
    Column(
        modifier.verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Chip(t("Single", "एक टाइमर"), e.timerMode == 0) { e.timerMode = 0 }
            Chip(t("Sections", "सेक्शन"), e.timerMode == 1) { e.timerMode = 1 }
        }
        if (e.timerMode == 0) {
            Txt(String.format(Locale.US, "%02d:00", e.singleMin), 56, FontWeight.Bold, modifier = Modifier.padding(vertical = 12.dp))
            for (row in listOf(listOf(5, 10, 15), listOf(25, 45, 60))) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEach { m -> Chip("$m $unit", e.singleMin == m) { e.singleMin = m } }
                }
            }
            Stepper(e.singleMin, unit, 1, 600) { e.singleMin = it }
            Spacer(Modifier.height(8.dp))
            Pill(t("Start", "शुरू करें"), true) {
                e.timer.load(listOf(Item(t("Timer", "टाइमर"), e.singleMin * 60000L)))
                e.timer.start()
                e.timerRun = true
            }
        } else {
            e.secs.forEachIndexed { i, s ->
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(Surf)
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = s.name,
                        onValueChange = { v ->
                            val l = e.secs.toMutableList()
                            l[i] = s.copy(name = v)
                            e.secs = l
                        },
                        placeholder = { Txt(t("Section ${i + 1}", "सेक्शन ${i + 1}"), 14, color = Mute) },
                        singleLine = true,
                        colors = tfColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(
                        Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Stepper(s.min, unit, 1, 300) { v ->
                            val l = e.secs.toMutableList()
                            l[i] = s.copy(min = v)
                            e.secs = l
                        }
                        if (e.secs.size > 1) {
                            Chip(t("Delete", "हटाएँ"), false) {
                                val l = e.secs.toMutableList()
                                l.removeAt(i)
                                e.secs = l
                            }
                        }
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Chip(t("+ Section", "+ सेक्शन"), false) { e.secs = e.secs + SecEdit("", 15) }
                Chip("4 × 15", false) { e.secs = List(4) { SecEdit("", 15) } }
            }
            Txt(t("Total", "कुल") + ": " + e.secs.sumOf { it.min } + " " + unit, 14, color = Mute)
            Pill(t("Start", "शुरू करें"), true) {
                val list = e.secs.mapIndexed { i, s ->
                    Item(s.name.ifBlank { t("Section ${i + 1}", "सेक्शन ${i + 1}") }, s.min * 60000L)
                }
                e.timer.load(list)
                e.timer.start()
                e.timerRun = true
            }
        }
    }
}

@Composable
fun StopwatchScreen() {
    val sw = Engines.sw
    val view = LocalView.current
    SideEffect { view.keepScreenOn = sw.running }
    Column(Modifier.fillMaxSize()) {
        Header(t("Stopwatch", "स्टॉपवॉच"), t("Track time per question", "हर सवाल का समय नापें"))
        Column(
            Modifier.weight(1f).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            Txt(fmtSw(sw.elapsedMs), 52, FontWeight.Bold, modifier = Modifier.padding(top = 16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Pill(t("Reset", "रीसेट"), false) { sw.reset() }
                Pill(t("Lap", "लैप"), false, sw.running) { sw.lap() }
                Pill(if (sw.running) t("Pause", "रोकें") else t("Start", "शुरू"), true) {
                    if (sw.running) sw.pause() else sw.start()
                }
            }
            LazyColumn(Modifier.fillMaxWidth().weight(1f)) {
                itemsIndexed(sw.laps) { i, lap ->
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Txt(t("Lap", "लैप") + " " + (sw.laps.size - i), 15, color = Mute)
                        Txt(fmtSw(lap.first), 15)
                        Txt(fmtSw(lap.second), 15, color = Mute)
                    }
                }
            }
        }
    }
}

@Composable
fun PomodoroScreen() {
    val e = Engines
    val unit = t("min", "मिनट")
    Column(Modifier.fillMaxSize()) {
        Header(t("Pomodoro", "पोमोडोरो"), t("Focus in short, sharp sessions", "छोटे-छोटे सत्रों में ध्यान लगाएँ"))
        if (e.pomoRun) {
            ChainRun(e.pomo, Modifier.weight(1f)) {
                e.pomo.reset()
                e.pomoRun = false
            }
        } else {
            Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                Txt(t("Focus", "फ़ोकस"), 14, color = Mute)
                Stepper(e.pFocus, unit, 1, 120) { e.pFocus = it }
                Txt(t("Break", "ब्रेक"), 14, color = Mute)
                Stepper(e.pBreak, unit, 1, 60) { e.pBreak = it }
                Txt(t("Sessions", "सत्र"), 14, color = Mute)
                Stepper(e.pRounds, "", 1, 12) { e.pRounds = it }
                Spacer(Modifier.height(8.dp))
                Pill(t("Start", "शुरू करें"), true) {
                    val list = buildList {
                        for (r in 1..e.pRounds) {
                            add(Item(t("Focus", "फ़ोकस") + " " + r, e.pFocus * 60000L))
                            if (r < e.pRounds) {
                                add(Item(t("Break", "ब्रेक"), e.pBreak * 60000L))
                            } else {
                                add(Item(t("Long break", "लंबा ब्रेक"), e.pBreak * 3 * 60000L))
                            }
                        }
                    }
                    e.pomo.load(list)
                    e.pomo.start()
                    e.pomoRun = true
                }
            }
        }
    }
}

@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize()) {
        Header(t("Settings", "सेटिंग्स"), "TimerGuru 1.0.0")
        Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Txt(t("Language", "भाषा"), 14, color = Mute)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Chip("हिंदी", Prefs.lang == Lang.HI) { Prefs.set(ctx, Lang.HI) }
                Chip("English", Prefs.lang == Lang.EN) { Prefs.set(ctx, Lang.EN) }
            }
            Spacer(Modifier.height(12.dp))
            Txt(
                t(
                    "Mock Test, Alarm and Goals are coming in the next update.",
                    "मॉक टेस्ट, अलार्म और लक्ष्य अगले अपडेट में आएँगे।"
                ),
                14, color = Mute
            )
        }
    }
}

@Composable
fun LangPick() {
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        Arrangement.Center,
        Alignment.CenterHorizontally
    ) {
        Txt("TimerGuru", 36, FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Txt("Choose your language\nभाषा चुनें", 16, color = Mute, align = TextAlign.Center)
        Spacer(Modifier.height(32.dp))
        Pill("हिंदी", true) { Prefs.set(ctx, Lang.HI) }
        Spacer(Modifier.height(12.dp))
        Pill("English", false) { Prefs.set(ctx, Lang.EN) }
    }
}

@Composable
fun TabBar(tab: Int, onTab: (Int) -> Unit) {
    val labels = listOf(
        t("Timer", "टाइमर"), t("Stopwatch", "स्टॉपवॉच"),
        t("Pomodoro", "पोमोडोरो"), t("Settings", "सेटिंग्स")
    )
    Row(
        Modifier.fillMaxWidth().background(Surf).padding(horizontal = 8.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceAround
    ) {
        labels.forEachIndexed { i, l ->
            Box(
                Modifier
                    .defaultMinSize(minHeight = 44.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(if (i == tab) Amber else Color.Transparent)
                    .clickable { onTab(i) }
                    .padding(horizontal = 14.dp),
                contentAlignment = Alignment.Center
            ) {
                Txt(l, 13, FontWeight.SemiBold, if (i == tab) BgC else Mute)
            }
        }
    }
}

@Composable
fun App() {
    var tab by rememberSaveable { mutableStateOf(0) }
    Column(Modifier.fillMaxSize().background(BgC)) {
        if (!Prefs.langChosen) {
            LangPick()
        } else {
            Box(Modifier.weight(1f)) {
                when (tab) {
                    0 -> TimerScreen()
                    1 -> StopwatchScreen()
                    2 -> PomodoroScreen()
                    else -> SettingsScreen()
                }
            }
            TabBar(tab) { tab = it }
        }
    }
}
