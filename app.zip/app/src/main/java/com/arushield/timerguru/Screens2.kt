package com.arushield.timerguru

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.time.LocalDate
import java.util.Locale

@Composable
fun swColors() = SwitchDefaults.colors(
    checkedThumbColor = BgC,
    checkedTrackColor = Amber,
    checkedBorderColor = Amber,
    uncheckedThumbColor = Mute,
    uncheckedTrackColor = Line,
    uncheckedBorderColor = Line
)

data class MockPreset(val name: String, val min: Int, val secs: List<Pair<String, String>>)

val MockPresets = listOf(
    MockPreset(
        "SSC CGL Tier 1", 60,
        listOf(
            "Reasoning" to "तर्कशक्ति", "Quant" to "गणित",
            "English" to "अंग्रेज़ी", "General Awareness" to "सामान्य जागरूकता"
        )
    ),
    MockPreset(
        "SSC CHSL Tier 1", 60,
        listOf(
            "English" to "अंग्रेज़ी", "Reasoning" to "तर्कशक्ति",
            "Quant" to "गणित", "General Awareness" to "सामान्य जागरूकता"
        )
    ),
    MockPreset(
        "RRB NTPC CBT-1", 90,
        listOf(
            "Mathematics" to "गणित", "Reasoning" to "तर्कशक्ति",
            "General Awareness" to "सामान्य जागरूकता"
        )
    )
)

@Composable
fun MockScreen() {
    val e = Engines
    Column(Modifier.fillMaxSize()) {
        Header(
            t("Mock Test", "मॉक टेस्ट"),
            t("Full-length practice with section timing", "पूरे टेस्ट का अभ्यास, सेक्शन के समय के साथ")
        )
        if (e.mockRun) MockRun(Modifier.weight(1f)) else MockSetup(Modifier.weight(1f))
    }
}

@Composable
fun MockSetup(modifier: Modifier) {
    val e = Engines
    val unit = t("min", "मिनट")
    Column(
        modifier.verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MockPresets.forEach { p ->
                Chip(p.name, false) {
                    e.mockTotalMin = p.min
                    e.mockSecs = p.secs.map { s -> t(s.first, s.second) }
                }
            }
        }
        Txt(t("Total time", "कुल समय"), 14, color = Mute)
        Stepper(e.mockTotalMin, unit, 5, 300, 5) { e.mockTotalMin = it }
        Txt(t("Sections", "सेक्शन"), 14, color = Mute)
        e.mockSecs.forEachIndexed { i, nm ->
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = nm,
                    onValueChange = { v ->
                        val l = e.mockSecs.toMutableList()
                        l[i] = v
                        e.mockSecs = l
                    },
                    placeholder = { Txt(t("Section ${i + 1}", "सेक्शन ${i + 1}"), 14, color = Mute) },
                    singleLine = true,
                    colors = tfColors(),
                    modifier = Modifier.weight(1f)
                )
                if (e.mockSecs.size > 1) {
                    Chip(t("Delete", "हटाएँ"), false) {
                        val l = e.mockSecs.toMutableList()
                        l.removeAt(i)
                        e.mockSecs = l
                    }
                }
            }
        }
        Chip(t("+ Section", "+ सेक्शन"), false) { e.mockSecs = e.mockSecs + "" }
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Txt(
                t("Warn in the last 5 minutes", "आख़िरी 5 मिनट में चेतावनी"), 15,
                modifier = Modifier.weight(1f)
            )
            Switch(checked = e.mockWarn, onCheckedChange = { e.mockWarn = it }, colors = swColors())
        }
        Txt(
            t(
                "Exam patterns can change, so edit the time and sections if needed.",
                "परीक्षा का पैटर्न बदल सकता है, इसलिए ज़रूरत हो तो समय और सेक्शन बदल लें।"
            ),
            12, color = Mute
        )
        Pill(t("Start", "शुरू करें"), true) { e.mockStart() }
    }
}

@Composable
fun MockRun(modifier: Modifier) {
    val e = Engines
    val m = e.mock
    val view = LocalView.current
    SideEffect { view.keepScreenOn = m.running }
    val unit = t("min", "मिनट")
    Column(
        modifier.verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        if (m.finished) {
            Txt(t("Test complete", "टेस्ट पूरा हुआ"), 28, FontWeight.Bold, Amber)
            Txt(
                t("Time used", "लगा हुआ समय") + ": " + fmt(e.mockTotalMin * 60000L - m.remainingMs),
                16, color = Mute
            )
        } else {
            Txt(fmt(m.remainingMs), 56, FontWeight.Bold, if (m.warning) Color(0xFFFF6B6B) else Ink)
            Txt(t("time left", "समय शेष") + " · " + e.mockTotalMin + " " + unit, 13, color = Mute)
        }
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(Surf)
                .padding(horizontal = 16.dp, vertical = 4.dp)
        ) {
            e.mockSecs.forEachIndexed { i, nm ->
                val done = i < e.mockIdx || (m.finished && i == e.mockIdx)
                val now = !m.finished && i == e.mockIdx
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Txt(
                        (if (done) "✓  " else if (now) "●  " else "○  ") +
                            nm.ifBlank { t("Section ${i + 1}", "सेक्शन ${i + 1}") },
                        15,
                        if (now) FontWeight.Bold else FontWeight.Normal,
                        if (now) Amber else if (done) Mute else Ink
                    )
                    Txt(if (i <= e.mockIdx) fmt(e.mockSecTime(i)) else "—", 15, color = Mute)
                }
            }
        }
        if (m.finished) {
            Pill(t("Done", "ठीक है"), true) {
                m.reset()
                e.mockRun = false
            }
        } else {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Pill(if (m.running) t("Pause", "रोकें") else t("Resume", "जारी रखें"), true) {
                    if (m.running) m.pause() else m.start()
                }
                if (e.mockIdx + 1 < e.mockSecs.size) {
                    Pill(t("Next section", "अगला सेक्शन"), false) { e.mockNext() }
                }
            }
            Pill(t("Submit", "जमा करें"), false) { m.finishNow() }
        }
    }
}

fun fmtTime(h: Int, m: Int): String {
    val h12 = if (h % 12 == 0) 12 else h % 12
    return String.format(Locale.US, "%02d:%02d %s", h12, m, if (h < 12) "AM" else "PM")
}

fun daysText(days: List<Int>): String {
    if (days.isEmpty()) return t("Once", "एक बार")
    if (days.size == 7) return t("Every day", "हर दिन")
    val en = listOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")
    val hi = listOf("रवि", "सोम", "मंगल", "बुध", "गुरु", "शुक्र", "शनि")
    return days.sorted().joinToString(", ") { t(en[it - 1], hi[it - 1]) }
}

@Composable
fun AlarmScreen() {
    val e = Engines
    Column(Modifier.fillMaxSize()) {
        Header(t("Alarm", "अलार्म"), t("Reminders for your study time", "पढ़ाई के समय के लिए रिमाइंडर"))
        val ed = e.alarmEdit
        if (ed != null) AlarmEditor(ed, Modifier.weight(1f)) else AlarmList(Modifier.weight(1f))
    }
}

@Composable
fun AlarmList(modifier: Modifier) {
    val ctx = LocalContext.current
    val e = Engines
    Column(
        modifier.verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (Alarms.list.isEmpty()) {
            Txt(t("No alarms yet", "अभी कोई अलार्म नहीं है"), 16, color = Mute, modifier = Modifier.padding(vertical = 24.dp))
        }
        Alarms.list.forEach { a ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(Surf)
                    .clickable { e.alarmEdit = a }
                    .padding(20.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(Modifier.weight(1f)) {
                    Txt(fmtTime(a.hour, a.minute), 30, FontWeight.Bold, if (a.enabled) Ink else Mute)
                    if (a.label.isNotBlank()) Txt(a.label, 14)
                    Txt(daysText(a.days), 13, color = Mute)
                }
                Switch(
                    checked = a.enabled,
                    onCheckedChange = { Alarms.upsert(ctx, a.copy(enabled = it)) },
                    colors = swColors()
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        Pill(t("New alarm", "नया अलार्म"), true) {
            e.alarmEdit = AlarmItem(Alarms.nextId(), 6, 0, "", emptyList(), true)
        }
    }
}

@Composable
fun AlarmEditor(ed: AlarmItem, modifier: Modifier) {
    val ctx = LocalContext.current
    val e = Engines
    val exists = Alarms.list.any { it.id == ed.id }
    val en = listOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")
    val hi = listOf("रवि", "सोम", "मंगल", "बुध", "गुरु", "शुक्र", "शनि")
    Column(
        modifier.verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Txt(fmtTime(ed.hour, ed.minute), 48, FontWeight.Bold)
        Chip(t("Change time", "समय बदलें"), false) {
            TimePickerDialog(
                ctx, android.R.style.Theme_Material_Dialog_Alert,
                { _, h, m -> e.alarmEdit = e.alarmEdit?.copy(hour = h, minute = m) },
                ed.hour, ed.minute, false
            ).show()
        }
        OutlinedTextField(
            value = ed.label,
            onValueChange = { e.alarmEdit = ed.copy(label = it) },
            placeholder = { Txt(t("Label", "नाम"), 14, color = Mute) },
            singleLine = true,
            colors = tfColors(),
            modifier = Modifier.fillMaxWidth()
        )
        Txt(t("Repeat", "दोहराएँ"), 14, color = Mute)
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            for (d in 1..7) {
                Chip(t(en[d - 1], hi[d - 1]), ed.days.contains(d)) {
                    val nd = if (ed.days.contains(d)) ed.days.filter { it != d } else ed.days + d
                    e.alarmEdit = ed.copy(days = nd.sorted())
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Pill(t("Cancel", "रद्द करें"), false) { e.alarmEdit = null }
            Pill(t("Save", "सेव करें"), true) {
                Alarms.upsert(ctx, ed.copy(enabled = true))
                e.alarmEdit = null
            }
        }
        if (exists) {
            Chip(t("Delete", "हटाएँ"), false) {
                Alarms.remove(ctx, ed.id)
                e.alarmEdit = null
            }
        }
    }
}

fun dayLetter(epochDay: Long): String {
    val v = LocalDate.ofEpochDay(epochDay).dayOfWeek.value
    val en = listOf("M", "T", "W", "T", "F", "S", "S")
    val hi = listOf("सो", "मं", "बु", "गु", "शु", "श", "र")
    return t(en[v - 1], hi[v - 1])
}

@Composable
fun GoalsScreen() {
    val ctx = LocalContext.current
    val ver = StudyLog.version
    val today = LocalDate.now().toEpochDay()
    val goalMs = Goals.goalMin * 60000L
    Column(Modifier.fillMaxSize()) {
        Header(
            t("Goals", "लक्ष्य"),
            t("Exam countdown, daily target and streak", "परीक्षा की गिनती, रोज़ का लक्ष्य और लगातार दिन")
        )
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Panel {
                Txt(t("Exam countdown", "परीक्षा में बचे दिन"), 13, color = Mute)
                if (Goals.examDay >= 0) {
                    val days = Goals.examDay - today
                    if (Goals.examName.isNotBlank()) Txt(Goals.examName, 20, FontWeight.Bold)
                    Txt(
                        if (days >= 0) "$days " + t("days", "दिन") else t("Exam is over", "परीक्षा हो चुकी है"),
                        44, FontWeight.Bold, Amber
                    )
                    Txt(LocalDate.ofEpochDay(Goals.examDay).toString(), 13, color = Mute)
                } else {
                    Txt(t("No exam set", "कोई परीक्षा तय नहीं"), 16)
                }
                OutlinedTextField(
                    value = Goals.examName,
                    onValueChange = {
                        Goals.examName = it
                        Goals.save(ctx)
                    },
                    placeholder = { Txt(t("Exam name", "परीक्षा का नाम"), 14, color = Mute) },
                    singleLine = true,
                    colors = tfColors(),
                    modifier = Modifier.fillMaxWidth()
                )
                Chip(t("Pick date", "तारीख़ चुनें"), false) {
                    val d = if (Goals.examDay >= 0) LocalDate.ofEpochDay(Goals.examDay) else LocalDate.now()
                    DatePickerDialog(
                        ctx, android.R.style.Theme_Material_Dialog_Alert,
                        { _, y, mo, dd ->
                            Goals.examDay = LocalDate.of(y, mo + 1, dd).toEpochDay()
                            Goals.save(ctx)
                        },
                        d.year, d.monthValue - 1, d.dayOfMonth
                    ).show()
                }
            }
            Panel {
                Txt(t("Daily goal", "रोज़ का लक्ष्य"), 13, color = Mute)
                Txt(fmtHm(StudyLog.todayMs) + " / " + fmtHm(goalMs), 18, FontWeight.SemiBold)
                val ratio = (StudyLog.todayMs.toFloat() / goalMs.toFloat()).coerceIn(0f, 1f)
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Line)
                ) {
                    Box(Modifier.fillMaxWidth(ratio).fillMaxHeight().background(Amber))
                }
                StepperText(
                    fmtHm(goalMs),
                    {
                        Goals.goalMin = (Goals.goalMin - 15).coerceAtLeast(15)
                        Goals.save(ctx)
                    },
                    {
                        Goals.goalMin = (Goals.goalMin + 15).coerceAtMost(960)
                        Goals.save(ctx)
                    }
                )
            }
            Panel {
                Txt(t("Streak", "लगातार दिन"), 13, color = Mute)
                Txt(StudyLog.streak().toString() + " " + t("day streak", "दिन लगातार"), 18, FontWeight.SemiBold)
                Txt(t("Last 7 days", "पिछले 7 दिन"), 12, color = Mute)
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    for (i in 6 downTo 0) {
                        val day = today - i
                        val ms = StudyLog.msOn(day)
                        val r = (ms.toFloat() / goalMs.toFloat()).coerceIn(0f, 1f)
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                Modifier
                                    .width(28.dp)
                                    .height((6 + 54 * r).dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (r >= 1f) Amber else if (ms > 0L) Mute else Line)
                            )
                            Txt(dayLetter(day), 11, color = Mute)
                        }
                    }
                }
            }
        }
    }
}
