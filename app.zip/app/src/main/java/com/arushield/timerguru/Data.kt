package com.arushield.timerguru

import android.content.Context
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

data class AlarmItem(
    val id: Int,
    val hour: Int,
    val minute: Int,
    val label: String,
    val days: List<Int>,
    val enabled: Boolean
)

data class Preset(val name: String, val secs: List<SecEdit>)

private fun sp(ctx: Context) = ctx.getSharedPreferences("tg", Context.MODE_PRIVATE)

object Alarms {
    var list by mutableStateOf(listOf<AlarmItem>())

    fun load(ctx: Context) {
        val out = mutableListOf<AlarmItem>()
        try {
            val arr = JSONArray(sp(ctx).getString("alarms", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val d = o.getJSONArray("d")
                out.add(
                    AlarmItem(
                        o.getInt("id"), o.getInt("h"), o.getInt("m"),
                        o.optString("l", ""),
                        List(d.length()) { d.getInt(it) },
                        o.getBoolean("e")
                    )
                )
            }
        } catch (_: Exception) {
        }
        list = out
    }

    private fun save(ctx: Context) {
        val arr = JSONArray()
        list.forEach { a ->
            val o = JSONObject()
            o.put("id", a.id)
            o.put("h", a.hour)
            o.put("m", a.minute)
            o.put("l", a.label)
            o.put("d", JSONArray(a.days))
            o.put("e", a.enabled)
            arr.put(o)
        }
        sp(ctx).edit().putString("alarms", arr.toString()).apply()
    }

    fun upsert(ctx: Context, a: AlarmItem) {
        list = if (list.any { it.id == a.id }) list.map { if (it.id == a.id) a else it } else list + a
        save(ctx)
        if (a.enabled) AlarmScheduler.schedule(ctx, a) else AlarmScheduler.cancel(ctx, a.id)
    }

    fun remove(ctx: Context, id: Int) {
        list = list.filter { it.id != id }
        save(ctx)
        AlarmScheduler.cancel(ctx, id)
    }

    fun nextId(): Int = (list.maxOfOrNull { it.id } ?: 0) + 1
}

object Presets {
    var list by mutableStateOf(listOf<Preset>())

    fun load(ctx: Context) {
        val out = mutableListOf<Preset>()
        try {
            val arr = JSONArray(sp(ctx).getString("presets", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val s = o.getJSONArray("s")
                val secs = List(s.length()) {
                    val so = s.getJSONObject(it)
                    SecEdit(so.optString("n", ""), so.getInt("m"))
                }
                out.add(Preset(o.getString("n"), secs))
            }
        } catch (_: Exception) {
        }
        list = out
    }

    private fun save(ctx: Context) {
        val arr = JSONArray()
        list.forEach { p ->
            val s = JSONArray()
            p.secs.forEach { x ->
                val so = JSONObject()
                so.put("n", x.name)
                so.put("m", x.min)
                s.put(so)
            }
            val o = JSONObject()
            o.put("n", p.name)
            o.put("s", s)
            arr.put(o)
        }
        sp(ctx).edit().putString("presets", arr.toString()).apply()
    }

    fun add(ctx: Context, name: String, secs: List<SecEdit>) {
        list = list.filter { it.name != name } + Preset(name, secs)
        save(ctx)
    }

    fun remove(ctx: Context, name: String) {
        list = list.filter { it.name != name }
        save(ctx)
    }
}

object Goals {
    var goalMin by mutableIntStateOf(240)
    var examName by mutableStateOf("")
    var examDay by mutableLongStateOf(-1L)

    fun load(ctx: Context) {
        val p = sp(ctx)
        goalMin = p.getInt("goalMin", 240)
        examName = p.getString("examName", "") ?: ""
        examDay = p.getLong("examDay", -1L)
    }

    fun save(ctx: Context) {
        sp(ctx).edit()
            .putInt("goalMin", goalMin)
            .putString("examName", examName)
            .putLong("examDay", examDay)
            .apply()
    }
}

object StudyLog {
    var todayMs by mutableLongStateOf(0L)
        private set
    var version by mutableIntStateOf(0)
        private set

    private val map = mutableMapOf<Long, Long>()
    private var lastFlush = 0L

    fun load(ctx: Context) {
        map.clear()
        try {
            val o = JSONObject(sp(ctx).getString("study", "{}"))
            val keys = o.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                map[k.toLong()] = o.getLong(k)
            }
        } catch (_: Exception) {
        }
        todayMs = msOn(LocalDate.now().toEpochDay())
        version += 1
    }

    fun add(ctx: Context, ms: Long) {
        if (ms <= 0L) return
        val d = LocalDate.now().toEpochDay()
        val total = (map[d] ?: 0L) + ms
        map[d] = total
        todayMs = total
        version += 1
        val now = SystemClock.elapsedRealtime()
        if (now - lastFlush > 10000L) flush(ctx)
    }

    fun flush(ctx: Context) {
        lastFlush = SystemClock.elapsedRealtime()
        val cutoff = LocalDate.now().toEpochDay() - 60
        val o = JSONObject()
        map.forEach { (k, v) -> if (k >= cutoff) o.put(k.toString(), v) }
        sp(ctx).edit().putString("study", o.toString()).apply()
    }

    fun msOn(day: Long): Long = map[day] ?: 0L

    fun streak(): Int {
        val today = LocalDate.now().toEpochDay()
        var d = if (msOn(today) >= 60000L) today else today - 1
        var n = 0
        while (msOn(d) >= 60000L) {
            n += 1
            d -= 1
        }
        return n
    }
}
