package com.arushield.timerguru

import android.content.Context
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale

enum class Lang { EN, HI }

object Prefs {
    var lang by mutableStateOf(Lang.EN)
    var langChosen by mutableStateOf(false)

    fun load(ctx: Context) {
        val p = ctx.getSharedPreferences("tg", Context.MODE_PRIVATE)
        langChosen = p.contains("lang")
        lang = if (p.getString("lang", "en") == "hi") Lang.HI else Lang.EN
    }

    fun set(ctx: Context, l: Lang) {
        lang = l
        langChosen = true
        ctx.getSharedPreferences("tg", Context.MODE_PRIVATE)
            .edit()
            .putString("lang", if (l == Lang.HI) "hi" else "en")
            .apply()
    }
}

fun t(en: String, hi: String): String = if (Prefs.lang == Lang.HI) hi else en

fun fmt(ms: Long): String {
    val total = (ms + 999) / 1000
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
    else String.format(Locale.US, "%02d:%02d", m, s)
}

fun fmtSw(ms: Long): String {
    val m = ms / 60000
    val s = (ms / 1000) % 60
    val c = (ms % 1000) / 10
    return String.format(Locale.US, "%02d:%02d.%02d", m, s, c)
}

object Alert {
    private var ringtone: Ringtone? = null

    fun fire(ctx: Context) {
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            ringtone?.stop()
            ringtone = RingtoneManager.getRingtone(ctx.applicationContext, uri)
            ringtone?.play()
            CoroutineScope(Dispatchers.Main).launch {
                delay(4000)
                ringtone?.stop()
            }
        } catch (_: Exception) {
        }
        try {
            val v = ctx.getSystemService(Vibrator::class.java)
            v?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 400, 200, 400), -1))
        } catch (_: Exception) {
        }
    }
}

data class Item(val name: String, val ms: Long)

data class SecEdit(val name: String, val min: Int)

class ChainTimer(private val ctx: Context) {
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    var items by mutableStateOf(listOf<Item>())
        private set
    var index by mutableIntStateOf(0)
        private set
    var remainingMs by mutableLongStateOf(0L)
        private set
    var running by mutableStateOf(false)
        private set
    var finished by mutableStateOf(false)
        private set
    var spent by mutableStateOf(listOf<Long>())
        private set

    private var job: Job? = null
    private var endAt = 0L

    fun load(list: List<Item>) {
        job?.cancel()
        running = false
        finished = false
        items = list
        index = 0
        remainingMs = list.firstOrNull()?.ms ?: 0L
        spent = list.map { 0L }
    }

    fun start() {
        if (items.isEmpty() || running) return
        if (finished) load(items)
        running = true
        endAt = SystemClock.elapsedRealtime() + remainingMs
        job = scope.launch {
            while (isActive) {
                val left = endAt - SystemClock.elapsedRealtime()
                if (left <= 0) {
                    markSpent(index, items[index].ms)
                    Alert.fire(ctx)
                    if (index + 1 < items.size) {
                        index += 1
                        remainingMs = items[index].ms
                        endAt = SystemClock.elapsedRealtime() + remainingMs
                    } else {
                        remainingMs = 0L
                        running = false
                        finished = true
                        return@launch
                    }
                } else {
                    remainingMs = left
                }
                delay(100)
            }
        }
    }

    fun pause() {
        job?.cancel()
        running = false
    }

    private fun markSpent(i: Int, ms: Long) {
        val l = spent.toMutableList()
        if (i in l.indices) l[i] = ms
        spent = l
    }

    fun skip() {
        if (items.isEmpty() || finished) return
        val wasRunning = running
        job?.cancel()
        running = false
        markSpent(index, items[index].ms - remainingMs)
        if (index + 1 < items.size) {
            index += 1
            remainingMs = items[index].ms
            if (wasRunning) start()
        } else {
            remainingMs = 0L
            finished = true
        }
    }

    fun reset() {
        load(items)
    }
}

class Stopwatch {
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    var elapsedMs by mutableLongStateOf(0L)
        private set
    var running by mutableStateOf(false)
        private set
    var laps by mutableStateOf(listOf<Pair<Long, Long>>())
        private set

    private var job: Job? = null
    private var base = 0L
    private var lastLapAt = 0L

    fun start() {
        if (running) return
        running = true
        base = SystemClock.elapsedRealtime() - elapsedMs
        job = scope.launch {
            while (isActive) {
                elapsedMs = SystemClock.elapsedRealtime() - base
                delay(30)
            }
        }
    }

    fun pause() {
        job?.cancel()
        running = false
    }

    fun lap() {
        if (!running) return
        laps = listOf((elapsedMs - lastLapAt) to elapsedMs) + laps
        lastLapAt = elapsedMs
    }

    fun reset() {
        job?.cancel()
        running = false
        elapsedMs = 0L
        laps = emptyList()
        lastLapAt = 0L
    }
}

object Engines {
    private var ready = false
    lateinit var timer: ChainTimer
    lateinit var pomo: ChainTimer
    lateinit var sw: Stopwatch

    var timerRun by mutableStateOf(false)
    var timerMode by mutableIntStateOf(0)
    var singleMin by mutableIntStateOf(25)
    var secs by mutableStateOf(List(4) { SecEdit("", 15) })

    var pomoRun by mutableStateOf(false)
    var pFocus by mutableIntStateOf(25)
    var pBreak by mutableIntStateOf(5)
    var pRounds by mutableIntStateOf(4)

    fun init(ctx: Context) {
        if (ready) return
        ready = true
        timer = ChainTimer(ctx)
        pomo = ChainTimer(ctx)
        sw = Stopwatch()
    }
}
