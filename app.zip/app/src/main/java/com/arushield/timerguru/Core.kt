package com.arushield.timerguru

import android.content.Context
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.PowerManager
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale

enum class Lang { EN, HI }

object Prefs {
    var lang by mutableStateOf(Lang.EN)
    var langChosen by mutableStateOf(false)

    fun load(ctx: Context) {
        val p = ctx.getSharedPreferences("tg", Context.MODE_PRIVATE)
        langChosen = p.contains("lang")
        lang = if (p.getString("lang", "en") == "hi") Lang.HI else Lang.EN
    }

    fun set(ctx: Context, l: Lang) {
        lang = l
        langChosen = true
        ctx.getSharedPreferences("tg", Context.MODE_PRIVATE)
            .edit()
            .putString("lang", if (l == Lang.HI) "hi" else "en")
            .apply()
    }
}

fun t(en: String, hi: String): String = if (Prefs.lang == Lang.HI) hi else en

fun fmt(ms: Long): String {
    val total = (ms + 999) / 1000
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
    else String.format(Locale.US, "%02d:%02d", m, s)
}

fun fmtSw(ms: Long): String {
    val m = ms / 60000
    val s = (ms / 1000) % 60
    val c = (ms % 1000) / 10
    return String.format(Locale.US, "%02d:%02d.%02d", m, s, c)
}

fun fmtHm(ms: Long): String {
    val m = ms / 60000
    return if (m >= 60) {
        (m / 60).toString() + t("h ", "घं ") + String.format(Locale.US, "%02d", m % 60) + t("m", "मि")
    } else {
        m.toString() + t("m", "मि")
    }
}

object Alert {
    private var ringtone: Ringtone? = null

    fun fire(ctx: Context) {
        val app = ctx.applicationContext
        try {
            val pm = app.getSystemService(Context.POWER_SERVICE) as PowerManager
            pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "timerguru:alert").acquire(6000L)
        } catch (_: Exception) {
        }
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            ringtone?.stop()
            ringtone = RingtoneManager.getRingtone(app, uri)
            ringtone?.play()
            CoroutineScope(Dispatchers.Main).launch {
                delay(4000)
                ringtone?.stop()
            }
        } catch (_: Exception) {
        }
        try {
            val v = app.getSystemService(Vibrator::class.java)
            v?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 400, 200, 400), -1))
        } catch (_: Exception) {
        }
    }
}

data class Item(val name: String, val ms: Long, val study: Boolean = true)

data class SecEdit(val name: String, val min: Int)

class ChainTimer(
    private val ctx: Context,
    private val code: Int,
    private val label: () -> String
) {
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    var items by mutableStateOf(listOf<Item>())
        private set
    var index by mutableIntStateOf(0)
        private set
    var remainingMs by mutableLongStateOf(0L)
        private set
    var running by mutableStateOf(false)
        private set
    var finished by mutableStateOf(false)
        private set
    var spent by mutableStateOf(listOf<Long>())
        private set
    var warning by mutableStateOf(false)
        private set

    var warnMs = 0L

    private var warnedIdx = -1
    private var job: Job? = null
    private var endAt = 0L
    private var lastTick = 0L

    fun load(list: List<Item>) {
        job?.cancel()
        TimerAlarm.cancel(ctx, code)
        running = false
        finished = false
        warning = false
        warnedIdx = -1
        items = list
        index = 0
        remainingMs = list.firstOrNull()?.ms ?: 0L
        spent = list.map { 0L }
    }

    fun start() {
        if (items.isEmpty() || running) return
        if (finished) load(items)
        running = true
        val now = SystemClock.elapsedRealtime()
        endAt = now + remainingMs
        lastTick = now
        TimerAlarm.set(ctx, code, System.currentTimeMillis() + remainingMs, label())
        TimerService.ensure(ctx)
        job?.cancel()
        job = scope.launch {
            while (isActive && running) {
                tick()
                delay(100)
            }
        }
    }

    fun tick() {
        if (!running) return
        val now = SystemClock.elapsedRealtime()
        val cur = items.getOrNull(index) ?: return
        if (cur.study) StudyLog.add(ctx, now - lastTick)
        lastTick = now
        var left = endAt - now
        var advanced = false
        while (left <= 0L) {
            markSpent(index, items[index].ms)
            if (index + 1 < items.size) {
                index += 1
                endAt += items[index].ms
                left = endAt - now
                advanced = true
            } else {
                remainingMs = 0L
                running = false
                finished = true
                warning = false
                TimerAlarm.cancel(ctx, code)
                StudyLog.flush(ctx)
                Alert.fire(ctx)
                Notifier.post(ctx, label(), t("Time is up", "समय पूरा हुआ"), 100 + code)
                return
            }
        }
        remainingMs = left
        val now2 = items[index]
        warning = warnMs > 0 && now2.ms > warnMs && left <= warnMs
        if (advanced) {
            Alert.fire(ctx)
            Notifier.post(ctx, label(), t("Now: ", "अब: ") + now2.name, 100 + code)
            TimerAlarm.set(ctx, code, System.currentTimeMillis() + left, label())
        }
        if (warning && warnedIdx != index) {
            warnedIdx = index
            Alert.fire(ctx)
        }
    }

    fun pause() {
        if (!running) return
        tick()
        job?.cancel()
        running = false
        TimerAlarm.cancel(ctx, code)
        StudyLog.flush(ctx)
    }

    private fun markSpent(i: Int, ms: Long) {
        val l = spent.toMutableList()
        if (i in l.indices) l[i] = ms
        spent = l
    }

    fun skip() {
        if (items.isEmpty() || finished) return
        val wasRunning = running
        if (running) tick()
        if (finished) return
        job?.cancel()
        TimerAlarm.cancel(ctx, code)
        running = false
        markSpent(index, items[index].ms - remainingMs)
        if (index + 1 < items.size) {
            index += 1
            remainingMs = items[index].ms
            if (wasRunning) start()
        } else {
            remainingMs = 0L
            finished = true
        }
    }

    fun finishNow() {
        if (items.isEmpty()) return
        if (running) tick()
        if (finished) return
        job?.cancel()
        running = false
        TimerAlarm.cancel(ctx, code)
        markSpent(index, items[index].ms - remainingMs)
        finished = true
        warning = false
        StudyLog.flush(ctx)
    }

    fun reset() {
        load(items)
    }
}

class Stopwatch(private val ctx: Context) {
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    var elapsedMs by mutableLongStateOf(0L)
        private set
    var running by mutableStateOf(false)
        private set
    var laps by mutableStateOf(listOf<Pair<Long, Long>>())
        private set

    private var job: Job? = null
    private var base = 0L
    private var lastLapAt = 0L

    fun start() {
        if (running) return
        running = true
        base = SystemClock.elapsedRealtime() - elapsedMs
        var last = SystemClock.elapsedRealtime()
        TimerService.ensure(ctx)
        job = scope.launch {
            while (isActive) {
                val now = SystemClock.elapsedRealtime()
                elapsedMs = now - base
                StudyLog.add(ctx, now - last)
                last = now
                delay(30)
            }
        }
    }

    fun pause() {
        job?.cancel()
        running = false
        StudyLog.flush(ctx)
    }

    fun lap() {
        if (!running) return
        laps = listOf((elapsedMs - lastLapAt) to elapsedMs) + laps
        lastLapAt = elapsedMs
    }

    fun reset() {
        job?.cancel()
        running = false
        elapsedMs = 0L
        laps = emptyList()
        lastLapAt = 0L
        StudyLog.flush(ctx)
    }
}

object Engines {
    private var ready = false
    lateinit var timer: ChainTimer
    lateinit var pomo: ChainTimer
    lateinit var mock: ChainTimer
    lateinit var sw: Stopwatch

    var timerRun by mutableStateOf(false)
    var timerMode by mutableIntStateOf(0)
    var singleMin by mutableIntStateOf(25)
    var secs by mutableStateOf(List(4) { SecEdit("", 15) })
    var loadedPreset by mutableStateOf<String?>(null)

    var pomoRun by mutableStateOf(false)
    var pFocus by mutableIntStateOf(25)
    var pBreak by mutableIntStateOf(5)
    var pRounds by mutableIntStateOf(4)

    var mockRun by mutableStateOf(false)
    var mockTotalMin by mutableIntStateOf(60)
    var mockSecs by mutableStateOf(listOf("", "", "", ""))
    var mockWarn by mutableStateOf(true)
    var mockIdx by mutableIntStateOf(0)
    var mockSecSpent by mutableStateOf(listOf<Long>())
    var mockSecStartRem by mutableLongStateOf(0L)

    var alarmEdit by mutableStateOf<AlarmItem?>(null)

    fun init(ctx: Context) {
        if (ready) return
        ready = true
        val app = ctx.applicationContext
        Prefs.load(app)
        Alarms.load(app)
        Presets.load(app)
        StudyLog.load(app)
        Goals.load(app)
        timer = ChainTimer(app, 9001) { t("Timer", "टाइमर") }
        pomo = ChainTimer(app, 9002) { t("Pomodoro", "पोमोडोरो") }
        mock = ChainTimer(app, 9003) { t("Mock Test", "मॉक टेस्ट") }
        sw = Stopwatch(app)
        AlarmScheduler.rescheduleAll(app)
    }

    fun byCode(code: Int): ChainTimer = when (code) {
        9001 -> timer
        9002 -> pomo
        else -> mock
    }

    fun anyRunning(): Boolean = timer.running || pomo.running || mock.running || sw.running

    fun tickAll() {
        timer.tick()
        pomo.tick()
        mock.tick()
    }

    fun status(): String? {
        val parts = mutableListOf<String>()
        if (timer.running) parts.add(t("Timer", "टाइमर") + " " + fmt(timer.remainingMs))
        if (pomo.running) parts.add(t("Pomodoro", "पोमोडोरो") + " " + fmt(pomo.remainingMs))
        if (mock.running) parts.add(t("Mock Test", "मॉक टेस्ट") + " " + fmt(mock.remainingMs))
        if (sw.running) parts.add(t("Stopwatch", "स्टॉपवॉच") + " " + fmt(sw.elapsedMs))
        return if (parts.isEmpty()) null else parts.joinToString("  ·  ")
    }

    fun mockStart() {
        mock.warnMs = if (mockWarn) 5 * 60000L else 0L
        mock.load(listOf(Item(t("Mock Test", "मॉक टेस्ट"), mockTotalMin * 60000L)))
        mockIdx = 0
        mockSecSpent = mockSecs.map { 0L }
        mockSecStartRem = mockTotalMin * 60000L
        mock.start()
        mockRun = true
    }

    fun mockNext() {
        if (mockIdx + 1 >= mockSecs.size) return
        val used = (mockSecStartRem - mock.remainingMs).coerceAtLeast(0L)
        val l = mockSecSpent.toMutableList()
        if (mockIdx in l.indices) l[mockIdx] = used
        mockSecSpent = l
        mockSecStartRem = mock.remainingMs
        mockIdx += 1
    }

    fun mockSecTime(i: Int): Long = when {
        i < mockIdx -> mockSecSpent.getOrElse(i) { 0L }
        i == mockIdx -> (mockSecStartRem - mock.remainingMs).coerceAtLeast(0L)
        else -> 0L
    }
}
